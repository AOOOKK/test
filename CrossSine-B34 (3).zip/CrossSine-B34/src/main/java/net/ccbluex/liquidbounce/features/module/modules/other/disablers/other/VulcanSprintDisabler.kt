package net.ccbluex.liquidbounce.features.module.modules.other.disablers.other

import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.modules.other.disablers.DisablerMode
import net.minecraft.network.play.client.C0BPacketEntityAction


class VulcanSprintDisabler : DisablerMode("VulcanSprint") {

    /**
     * Vulcan OmniSprint Disabler
     * Code by Dg636
     * Date: 2023/03/21
     */
    
    override fun onUpdate(event: UpdateEvent) {
        mc.netHandler.addToSendQueue(C0BPacketEntityAction(mc.thePlayer, C0BPacketEntityAction.Action.START_SPRINTING))
        mc.netHandler.addToSendQueue(C0BPacketEntityAction(mc.thePlayer, C0BPacketEntityAction.Action.STOP_SPRINTING))
    }
}
