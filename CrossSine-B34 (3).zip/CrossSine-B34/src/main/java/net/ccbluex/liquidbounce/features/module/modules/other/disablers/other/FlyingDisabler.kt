package net.ccbluex.liquidbounce.features.module.modules.other.disablers.other

import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.features.module.modules.other.disablers.DisablerMode
import net.minecraft.entity.player.PlayerCapabilities
import net.minecraft.network.play.client.C03PacketPlayer
import net.minecraft.network.play.client.C13PacketPlayerAbilities

class FlyingDisabler : DisablerMode("Flying") {
    override fun onPacket(event: PacketEvent) {
        val packet = event.packet
        if (packet is C03PacketPlayer) {
            val capabilities = PlayerCapabilities()
            capabilities.disableDamage = false
            capabilities.isFlying = true
            capabilities.allowFlying = false
            capabilities.isCreativeMode = false
            mc.netHandler.addToSendQueue(C13PacketPlayerAbilities(capabilities))
            disabler.debugMessage("Send Packet C13")
        }
    }
}
