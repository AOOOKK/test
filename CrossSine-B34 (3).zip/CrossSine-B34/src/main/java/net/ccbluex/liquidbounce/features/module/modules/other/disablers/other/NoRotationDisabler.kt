package net.ccbluex.liquidbounce.features.module.modules.other.disablers.other

import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.features.module.modules.other.disablers.DisablerMode
import net.ccbluex.liquidbounce.features.value.ListValue
import net.ccbluex.liquidbounce.features.value.FloatValue
import net.ccbluex.liquidbounce.utils.PacketUtils
import net.minecraft.network.play.client.C03PacketPlayer
import net.minecraft.network.play.client.C03PacketPlayer.*

class NoRotationDisabler : DisablerMode("NoRotation") {
    private val modifyModeValue = ListValue("${valuePrefix}Mode", arrayOf("ConvertNull", "Spoof", "Zero", "SpoofZero", "Negative", "OffsetYaw", "Invalid"), "ConvertNull")
    private val offsetAmountValue = FloatValue("${valuePrefix}OffsetAmount", 6f, -180f, 180f)

    override fun onPacket(event: PacketEvent) {
        val packet = event.packet
        if (packet is C03PacketPlayer) {
            when(modifyModeValue.get()) {
                "ConvertNull" -> {
                    if(packet.isMoving) {
                        PacketUtils.sendPacketNoEvent(C04PacketPlayerPosition(packet.x, packet.y, packet.z, packet.onGround))
                    }else {
                        PacketUtils.sendPacketNoEvent(C03PacketPlayer(packet.onGround))
                    }
                    event.cancelEvent()
                }
                
                "Spoof" -> {
                    if(packet.getRotating()) {
                        packet.yaw = mc.thePlayer.rotationYaw
                        packet.pitch = mc.thePlayer.rotationPitch
                    }
                }
                
                "Zero" -> {
                    if(packet.getRotating()) {
                        packet.yaw = 0.0f
                        packet.pitch = 0.0f
                    }
                }
                
                "SpoofZero" -> {
                    if(packet.isMoving) {
                        PacketUtils.sendPacketNoEvent(C06PacketPlayerPosLook(packet.x, packet.y, packet.z, 0.0f, 0.0f, packet.onGround))
                    }else {
                        PacketUtils.sendPacketNoEvent(C06PacketPlayerPosLook(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ, 0.0f, 0.0f, packet.onGround))
                    }
                    event.cancelEvent()
                }
                
                "Negative" -> {
                    if(packet.getRotating()) {
                        packet.yaw = -packet.yaw
                        packet.pitch = -packet.pitch
                    }
                }
                
                "OffsetYaw" -> {
                    if(packet.getRotating()) {
                        packet.yaw += offsetAmountValue.get()
                    }
                }
            }
        }
    }
}
