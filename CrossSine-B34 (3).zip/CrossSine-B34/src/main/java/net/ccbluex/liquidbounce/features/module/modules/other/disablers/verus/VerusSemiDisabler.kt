package net.ccbluex.liquidbounce.features.module.modules.other.disablers.verus

import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.event.WorldEvent
import net.ccbluex.liquidbounce.features.module.modules.other.disablers.DisablerMode
import net.ccbluex.liquidbounce.features.value.IntegerValue
import net.ccbluex.liquidbounce.utils.PacketUtils
import net.minecraft.network.Packet
import net.minecraft.network.play.INetHandlerPlayServer
import net.minecraft.network.play.client.C0FPacketConfirmTransaction
import java.util.*

class VerusSemiDisabler : DisablerMode("VerusSemi") {
    private val bufferValue = IntegerValue("${valuePrefix}BufferSize", 30, 10, 100)
    private var currentTrans = 0
    private var verus2Stat = false
    private val packetBuffer = LinkedList<Packet<INetHandlerPlayServer>>()
    override fun onEnable() {
        currentTrans = 0
        verus2Stat = false
        packetBuffer.clear()
    }
    override fun onDisable() {
        for(packet in packetBuffer) {
            PacketUtils.sendPacketNoEvent(packet)
            packetBuffer.remove(packet)
        }
    }
    override fun onWorld(event: WorldEvent) {
        currentTrans = 0
        packetBuffer.clear()
    }

    override fun onUpdate(event: UpdateEvent) {
        if(packetBuffer.size >= bufferValue.get()) {
            verus2Stat = true
        }
        if(verus2Stat) {
            disabler.debugMessage("Packet C0F in ${packetBuffer.size}")
            for(packet in packetBuffer) {
                PacketUtils.sendPacketNoEvent(packet)
                packetBuffer.remove(packet)
            }

            verus2Stat = false
        }
    }
    override fun onPacket(event: PacketEvent) {
        val packet = event.packet
        if (packet is C0FPacketConfirmTransaction) {
            packetBuffer.add(packet)
            disabler.debugMessage("C0F Buffer")
            event.cancelEvent()
        }
    }
}
