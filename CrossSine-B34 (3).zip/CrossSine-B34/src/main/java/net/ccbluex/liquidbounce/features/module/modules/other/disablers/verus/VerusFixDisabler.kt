package net.ccbluex.liquidbounce.features.module.modules.other.disablers.verus

import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.features.module.modules.other.disablers.DisablerMode
import net.ccbluex.liquidbounce.features.value.BoolValue
import net.ccbluex.liquidbounce.utils.PacketUtils
import net.minecraft.network.play.client.C03PacketPlayer
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement
import net.minecraft.network.play.client.C09PacketHeldItemChange
import net.minecraft.network.play.client.C0BPacketEntityAction

class VerusFixDisabler : DisablerMode("VerusFix") {
    private val omniSprint13EValue = BoolValue("${valuePrefix}OmniSprint", true)
    private val scaffold14EValue = BoolValue("${valuePrefix}BlockPlace", true)
    private val fly4IValue = BoolValue("${valuePrefix}fly4I", true)
    var x = 0.0
    var y = 0.0
    var z = 0.0
    var pitch = 0.0
    var yaw = 0.0
    var prevSlot = 0
    private var jam = 0
    private var packetCount = 0
    
    override fun onPacket(event: PacketEvent) {
        val packet = event.packet
        if (mc.thePlayer == null || mc.theWorld == null || event.isCancelled)
            return
        // fix ground check (4I)
        if (packet is C03PacketPlayer && packet !is C03PacketPlayer.C04PacketPlayerPosition && packet !is C03PacketPlayer.C06PacketPlayerPosLook) {
            if ((mc.thePlayer.motionY == 0.0 || (mc.thePlayer.onGround && mc.thePlayer.isCollidedVertically)) && !packet.onGround) {
                packet.onGround = true
                disabler.debugMessage("Packet C03 OnGround Fix")
            }
        }

        // some info things
        if (packet is C03PacketPlayer.C04PacketPlayerPosition) {
            x = packet.x
            y = packet.y
            z = packet.z
            jam = 0
        }

        if (packet is C03PacketPlayer.C05PacketPlayerLook) {
            yaw = packet.yaw.toDouble()
            pitch = packet.pitch.toDouble()
        }

        if (packet is C03PacketPlayer.C06PacketPlayerPosLook) {
            x = packet.x
            y = packet.y
            z = packet.z
            jam = 0

            yaw = packet.yaw.toDouble()
            pitch = packet.pitch.toDouble()
        }

        if (packet is C03PacketPlayer && packet !is C03PacketPlayer.C04PacketPlayerPosition && packet !is C03PacketPlayer.C06PacketPlayerPosLook) {
            jam++
            if (jam > 20) {
                jam = 0
                event.cancelEvent()
                PacketUtils.sendPacketNoEvent(
                    C03PacketPlayer.C06PacketPlayerPosLook(
                        x,
                        y,
                        z,
                        yaw.toFloat(),
                        pitch.toFloat(),
                        packet.onGround
                    )
                )
                disabler.debugMessage("Packet C03 Spam Fix")
            }
        }

        // fix scaffold duplicated hotbar switch
        if (!mc.isSingleplayer && packet is C09PacketHeldItemChange) {
            if (packet.slotId == prevSlot) {
                event.cancelEvent()
                disabler.debugMessage("Packet C09 Duplicate Cancel")
            } else {
                prevSlot = packet.slotId
            }
        }

        if (omniSprint13EValue.get() && packet is C0BPacketEntityAction) {
            event.cancelEvent()
            disabler.debugMessage("Packet C0B Check Cancel")
        }

        if (scaffold14EValue.get() && packet is C08PacketPlayerBlockPlacement) {
            packet.facingX = packet.facingX.coerceIn(-1.00000F, 1.00000F)
            packet.facingY = packet.facingY.coerceIn(-1.00000F, 1.00000F)
            packet.facingZ = packet.facingZ.coerceIn(-1.00000F, 1.00000F)
            disabler.debugMessage("Packet C08 Placement Fix")
        }

        if (fly4IValue.get() && packet is C03PacketPlayer && !packet.onGround) {
            if (packet !is C03PacketPlayer.C04PacketPlayerPosition && packet !is C03PacketPlayer.C05PacketPlayerLook && packet !is C03PacketPlayer.C06PacketPlayerPosLook) {
                packetCount++
                if (packetCount >= 2) {
                    event.cancelEvent()
                    disabler.debugMessage("Packet C03 Flying Cancel")
                }
            } else {
                packetCount = 0
            }
        }
    }
}
