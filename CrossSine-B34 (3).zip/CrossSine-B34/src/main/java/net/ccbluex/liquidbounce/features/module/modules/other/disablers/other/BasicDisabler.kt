package net.ccbluex.liquidbounce.features.module.modules.other.disablers.other

import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.features.module.modules.other.disablers.DisablerMode
import net.ccbluex.liquidbounce.features.value.BoolValue
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.minecraft.network.play.client.C00PacketKeepAlive
import net.minecraft.network.play.client.C0FPacketConfirmTransaction
import net.minecraft.network.play.client.C0APacketAnimation
import net.minecraft.network.play.client.C0BPacketEntityAction
import net.minecraft.network.play.client.C03PacketPlayer
import net.minecraft.network.play.client.C03PacketPlayer.*

class BasicDisabler : DisablerMode("Basic") {
    private val cancelC00Value = BoolValue("${valuePrefix}CancelC00", true)
    private val cancelC0FValue = BoolValue("${valuePrefix}CancelC0F", true)
    private val cancelC0AValue = BoolValue("${valuePrefix}CancelC0A", true)
    private val cancelC0BValue = BoolValue("${valuePrefix}CancelC0B", true)
    private val cancelC03Value = BoolValue("${valuePrefix}CancelC03", true)
    private val c03NoMoveValue = BoolValue("${valuePrefix}C03-NoMove", true).displayable{ cancelC03Value.get() }
    
    override fun onPacket(event: PacketEvent) {
        val packet = event.packet
        if (packet is C0FPacketConfirmTransaction && cancelC0FValue.get()) {
            event.cancelEvent()
            disabler.debugMessage("Cancel C0F-Transaction")
        }
        if (packet is C00PacketKeepAlive && cancelC00Value.get()) {
            event.cancelEvent()
            disabler.debugMessage("Cancel C00-KeepAlive")
        }
        if (packet is C0APacketAnimation && cancelC0AValue.get()) {
            event.cancelEvent()
            disabler.debugMessage("Cancel C0A-Swing")
        }
        if (packet is C0BPacketEntityAction && cancelC0BValue.get()) {
            event.cancelEvent()
            disabler.debugMessage("Cancel C0B-Action")
        }
        if (packet is C03PacketPlayer && !(packet is C04PacketPlayerPosition || packet is C05PacketPlayerLook || packet is C06PacketPlayerPosLook) && cancelC03Value.get()) {
            if (c03NoMoveValue.get() && MovementUtils.isMoving())
                return
            event.cancelEvent()
            disabler.debugMessage("Cancel C03-Flying")
        }
    }
}
