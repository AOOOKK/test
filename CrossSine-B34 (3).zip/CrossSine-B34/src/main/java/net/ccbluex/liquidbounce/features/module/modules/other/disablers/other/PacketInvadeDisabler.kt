package net.ccbluex.liquidbounce.features.module.modules.other.disablers.other

import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.features.module.modules.other.disablers.DisablerMode
import net.ccbluex.liquidbounce.features.value.BoolValue
import net.ccbluex.liquidbounce.features.value.ListValue
import net.ccbluex.liquidbounce.features.value.IntegerValue
import net.ccbluex.liquidbounce.utils.misc.RandomUtils
import net.minecraft.network.play.client.C00PacketKeepAlive

class PacketInvadeDisabler : DisablerMode("PacketInvade") {
    private val modifyC00Value = BoolValue("${valuePrefix}ModifyC00", true)
    /*private val modifyC0FValue = BoolValue("${valuePrefix}ModifyC0F", true)*/
    private val modifyModeValue = ListValue("${valuePrefix}ModifyMode", arrayOf("Disturb", "InvalidDisturb", "Invalid", "Drift"), "Drift").displayable { modifyC00Value.get() }
    private val disturbAmountValue = IntegerValue("${valuePrefix}ModifyAmount", 128, 1, 256)
    private val negativeValue = BoolValue("${valuePrefix}Negative", true)
    override fun onPacket(event: PacketEvent) {
        val packet = event.packet/*
        if (packet is C0FPacketConfirmTransaction && modifyC0FValue.get()) {
            when(modifyModeValue.get()) {
                "Disturb" -> {
                    val amounts = RandomUtils.nextInt(1, disturbAmountValue.get() * 128)
                    if (negativeValue.get()) {
                        packet.uid -= amounts.toShort()
                    }else {
                        packet.uid += amounts.toShort()
                    }
                }
                "InvalidDisturb" -> {
                    val amounts = RandomUtils.nextInt(1024, 32767)
                    if (negativeValue.get()) {
                        packet.uid -= amounts.toShort()
                    }else {
                        packet.uid += amounts.toShort()
                    }
                }
                "Invalid" -> {
                    packet.uid = (0).toShort()
                }
                "Drift" -> {
                    if (negativeValue.get()) {
                        packet.uid -= (disturbAmountValue.get()).toShort()
                    }else {
                        packet.uid += (disturbAmountValue.get()).toShort()
                    }
                }
            }
            disabler.debugMessage("Modified C0F:"+packet.uid)
        }*/
        if (packet is C00PacketKeepAlive && modifyC00Value.get()) {
            when(modifyModeValue.get()) {
                "Disturb" -> {
                    val amounts = RandomUtils.nextInt(1, disturbAmountValue.get() * 1024)
                    if (negativeValue.get()) {
                        packet.key -= amounts
                    }else {
                        packet.key += amounts
                    }
                }
                "InvalidDisturb" -> {
                    val amounts = RandomUtils.nextInt(1024, 2147483647)
                    if (negativeValue.get()) {
                        packet.key -= amounts
                    }else {
                        packet.key += amounts
                    }
                }
                "Invalid" -> {
                    packet.key = 0
                }
                "Drift" -> {
                    if (negativeValue.get()) {
                        packet.key -= disturbAmountValue.get()
                    }else {
                        packet.key += disturbAmountValue.get()
                    }
                }
            }
            disabler.debugMessage("Modified C00:"+packet.key)
        }
    }
}
