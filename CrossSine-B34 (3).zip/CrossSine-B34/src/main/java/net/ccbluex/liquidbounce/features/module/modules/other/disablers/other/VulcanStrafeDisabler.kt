package net.ccbluex.liquidbounce.features.module.modules.other.disablers.other

import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.WorldEvent
import net.ccbluex.liquidbounce.features.module.modules.other.disablers.DisablerMode
import net.ccbluex.liquidbounce.features.value.BoolValue
import net.ccbluex.liquidbounce.features.value.IntegerValue
import net.ccbluex.liquidbounce.utils.PacketUtils
import net.minecraft.network.play.client.C07PacketPlayerDigging
import net.minecraft.network.play.client.C03PacketPlayer
import net.minecraft.util.BlockPos
import net.minecraft.util.EnumFacing

class VulcanStrafeDisabler : DisablerMode("VulcanStrafe") {
    private val avoidPhaseBpValue = BoolValue("${valuePrefix}NoBadPacket", true) //Avoid flags when phasing / clipping
    private val delayValue = IntegerValue("${valuePrefix}PacketDelay", 6, 3, 10) //保留备用，可能能够绕过别的反作弊
    private var c03Counter = 0
    
    /**
     * Vulcan Strafe Disabler (Also bypassed Jump / MotionC checks)
     * Code by Co Dynamic
     * Date: 2023/02/23
     * TODO: C08 can disable Speed C Check (place block in reachable place && place illegally)
     */
    
    override fun onEnable() {
        c03Counter = -15
    }
    override fun onWorld(event: WorldEvent) {
        c03Counter = -15 //avoid badpacket / time out (weird)
    }
    override fun onPacket(event: PacketEvent) {
        val packet = event.packet
        if (packet is C03PacketPlayer) {
            c03Counter++
            if (packet.isMoving) {
                if (c03Counter >= delayValue.get()) {
                    PacketUtils.sendPacketNoEvent(
                        C07PacketPlayerDigging(C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK,
                            if (avoidPhaseBpValue.get()) { BlockPos.ORIGIN } else { BlockPos(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ) }, EnumFacing.DOWN)
                    )
                    c03Counter = 0
                } else if (c03Counter == delayValue.get() - 2) {
                    PacketUtils.sendPacketNoEvent(
                        C07PacketPlayerDigging(C07PacketPlayerDigging.Action.START_DESTROY_BLOCK,
                            BlockPos.ORIGIN, EnumFacing.DOWN)
                    )
                }
            }
        }
    }
}
