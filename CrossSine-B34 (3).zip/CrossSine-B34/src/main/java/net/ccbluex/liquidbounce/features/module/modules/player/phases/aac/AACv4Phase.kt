package net.ccbluex.liquidbounce.features.module.modules.player.phases.aac

import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.modules.player.phases.PhaseMode
import net.minecraft.network.play.client.C03PacketPlayer

class AACv4Phase : PhaseMode("AACv4") {
    override fun onUpdate(event: UpdateEvent) {
        mc.thePlayer.sendQueue.addToSendQueue(
            C03PacketPlayer.C06PacketPlayerPosLook(
                mc.thePlayer.posX,
                mc.thePlayer.posY - 0.00000001,
                mc.thePlayer.posZ,
                mc.thePlayer.rotationYaw,
                mc.thePlayer.rotationPitch,
                false
            )
        )
        mc.thePlayer.sendQueue.addToSendQueue(
            C03PacketPlayer.C06PacketPlayerPosLook(
                mc.thePlayer.posX,
                mc.thePlayer.posY - 1,
                mc.thePlayer.posZ,
                mc.thePlayer.rotationYaw,
                mc.thePlayer.rotationPitch,
                false
            )
        )
        phase.state = false
    }
}