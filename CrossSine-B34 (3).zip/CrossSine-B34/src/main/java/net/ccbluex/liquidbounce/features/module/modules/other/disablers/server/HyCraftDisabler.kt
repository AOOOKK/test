package net.ccbluex.liquidbounce.features.module.modules.other.disablers.server

import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.features.module.modules.other.disablers.DisablerMode
import net.ccbluex.liquidbounce.features.value.BoolValue
import net.minecraft.network.play.client.C03PacketPlayer
import net.minecraft.network.play.server.S3EPacketTeams
import net.minecraft.network.play.server.S08PacketPlayerPosLook

class HyCraftDisabler : DisablerMode("HyCraftCrash") {
    private val invalidTeams = BoolValue("${valuePrefix}BlockTeams", false)
    private val invalidPosition = BoolValue("${valuePrefix}BlockInvalidPosition", true)
    
    override fun onPacket(event: PacketEvent) {
        val packet = event.packet
        if(packet is S3EPacketTeams && invalidTeams.get()) {
            disabler.debugMessage("Blocked Invalid S3EPacketTeams")
            event.cancelEvent()
        }
        if (packet is S08PacketPlayerPosLook && invalidPosition.get()) {
            val x = packet.x
            val y = packet.y
            val z = packet.z
            
            if (x >= 200000 || x <= -200000 ||
                y >= 200000 || y <= -200000 ||
                z >= 200000 || z <= -200000) {
                mc.netHandler.networkManager.sendPacket(C03PacketPlayer.C06PacketPlayerPosLook(x, y, z, packet.getYaw(), packet.getPitch(), false)  )
                disabler.debugMessage("Blocked Invalid S08PacketPlayerPosLook")
                event.cancelEvent()
            }
        }


    }
}
