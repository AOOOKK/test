package net.ccbluex.liquidbounce.features.module.modules.other.disablers.spectate

import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.features.module.modules.other.disablers.DisablerMode
import net.minecraft.network.play.client.C03PacketPlayer
import net.minecraft.network.play.client.C13PacketPlayerAbilities
import net.minecraft.network.play.client.C18PacketSpectate

class SpectateSpoofDisabler : DisablerMode("SpectateSpoof") {
    override fun onPacket(event: PacketEvent) {
        val packet = event.packet
        if (packet is C03PacketPlayer) {
            packet.onGround = false

            mc.netHandler.addToSendQueue(C18PacketSpectate(mc.thePlayer.uniqueID))
            mc.netHandler.addToSendQueue(C13PacketPlayerAbilities(mc.thePlayer.capabilities))
            disabler.debugMessage("Packet C18 + C13")
        }
        if (packet is C13PacketPlayerAbilities) {
            disabler.debugMessage("Packet C13")
            packet.isFlying = true
            packet.isInvulnerable = true
            packet.isAllowFlying = true
            packet.isCreativeMode = false
        }

    }
}