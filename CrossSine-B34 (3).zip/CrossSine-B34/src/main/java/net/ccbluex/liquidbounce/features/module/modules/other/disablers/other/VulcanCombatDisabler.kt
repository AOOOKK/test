package net.ccbluex.liquidbounce.features.module.modules.other.disablers.other

import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.event.WorldEvent
import net.ccbluex.liquidbounce.features.module.modules.other.disablers.DisablerMode
import net.ccbluex.liquidbounce.features.value.BoolValue
import net.ccbluex.liquidbounce.features.value.IntegerValue
import net.ccbluex.liquidbounce.utils.BlinkUtils
import net.ccbluex.liquidbounce.utils.PacketUtils
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.minecraft.network.play.client.C0FPacketConfirmTransaction
import net.minecraft.network.play.client.C0BPacketEntityAction
import kotlin.random.Random

class VulcanCombatDisabler : DisablerMode("VulcanCombat") {
    private val compDecValue = BoolValue("VulcanDecrease", true)
    private val statDecValue = IntegerValue("VulcanDecreaseDelay", 1500, 500, 2500).displayable { compDecValue.get() }
    private val dynamicValue = BoolValue("VulcanDynamicDelay", true)
    private val decDelayMinValue = IntegerValue("VulcanMinDelay", 4500, 2000, 8000).displayable { dynamicValue.get() }
    private val decDelayMaxValue = IntegerValue("VulcanMaxDelay", 5500, 2000, 8000).displayable { dynamicValue.get() }
    private val minBuffValue = IntegerValue("VulcanMinBuff", 5, 0, 12)
    private val noC0BValue = BoolValue("NoC0BPacket", false)
    private var currentTrans = 0
    
    //已经死了一半的Disabler，稍微复活一下。已经无法（只靠这个Disabler）绕过的Bypass：Vanilla Velocity / None Rotation
    
    private var currentDelay = 5000
    private var currentBuffer = 4
    private var currentDec = -1
    private val lagTimer = MSTimer()
    private val decTimer = MSTimer()
    private var runReset = false
    override fun onEnable() {
        updateLagTime()
    }

    override fun onDisable() {
        updateLagTime()
        BlinkUtils.releasePacket(packetType = "C0FPacketConfirmTransaction")
        BlinkUtils.setBlinkState(packetTransaction = false)
    }

    override fun onUpdate(event: UpdateEvent) {
        if (runReset) {
            runReset = false
            PacketUtils.sendPacketNoEvent(C0BPacketEntityAction(mc.thePlayer, C0BPacketEntityAction.Action.STOP_SPRINTING))
        }
        if (lagTimer.hasTimePassed(currentDelay.toLong()) && BlinkUtils.bufferSize(packetType = "C0FPacketConfirmTransaction") > currentBuffer) {
            updateLagTime()
            BlinkUtils.releasePacket(packetType = "C0FPacketConfirmTransaction", minBuff = currentBuffer)
            disabler.debugMessage("C0F-PingTickCounter RELEASE")
        }
        if (decTimer.hasTimePassed(currentDec.toLong()) && currentDec > 0) {
            BlinkUtils.releasePacket(packetType = "C0FPacketConfirmTransaction", amount = 1)
            disabler.debugMessage("C0F-PingTickCounter DECREASE")
            decTimer.reset()
        }
    }
    override fun onWorld(event: WorldEvent) {
        BlinkUtils.clearPacket(packetType = "C0FPacketConfirmTransaction")
        currentTrans = 0
        updateLagTime()
        runReset = noC0BValue.get()
    }
    override fun onPacket(event: PacketEvent) {
        val packet = event.packet
        if (packet is C0BPacketEntityAction && noC0BValue.get()) {
            event.cancelEvent()
            disabler.debugMessage("C0B-EntityAction CANCELLED")
        }
        if (packet is C0FPacketConfirmTransaction && disabler.state) {
            BlinkUtils.setBlinkState(packetTransaction = false)
            val transUID = (packet.uid).toInt()
            if (transUID >= -25767 && transUID <= -24769) {
                BlinkUtils.setBlinkState(packetTransaction = true)
                disabler.debugMessage("C0F-PingTickCounter IN ${BlinkUtils.bufferSize(packetType = "C0FPacketConfirmTransaction")}")
            }else if (transUID == -30000){
                BlinkUtils.setBlinkState(packetTransaction = true)
                disabler.debugMessage("C0F-OnSpawn IN ${BlinkUtils.bufferSize(packetType = "C0FPacketConfirmTransaction")}")
            }
        }
    }
    private fun updateLagTime() {
        decTimer.reset()
        lagTimer.reset()
        currentDelay = if (dynamicValue.get()) Random.nextInt(decDelayMinValue.get(), decDelayMaxValue.get()) else 5000
        currentDec = if (compDecValue.get()) statDecValue.get() else -1
        currentBuffer = minBuffValue.get()
    }
}
