package net.ccbluex.liquidbounce.features.module.modules.other.disablers.server

import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.modules.other.disablers.DisablerMode
import net.ccbluex.liquidbounce.utils.PacketUtils
import net.minecraft.network.play.client.C03PacketPlayer.*
import net.minecraft.network.play.server.S08PacketPlayerPosLook
import net.minecraft.util.BlockPos
import kotlin.math.sqrt

class HeirteirACDisabler : DisablerMode("HeirteirAC") {

    override fun onUpdate(event: UpdateEvent) {
        if (mc.thePlayer.ticksExisted < 120)
            return
        mc.netHandler.addToSendQueue(C04PacketPlayerPosition(
            mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ, false))
        mc.netHandler.addToSendQueue(C04PacketPlayerPosition(
            mc.thePlayer.posX, mc.thePlayer.posY + 490, mc.thePlayer.posZ, true))
    }

    override fun onPacket(event: PacketEvent) {
        val packet = event.packet
        if (mc.thePlayer.ticksExisted < 120)
            return

        if (packet is S08PacketPlayerPosLook) {
            val x = packet.x - mc.thePlayer.posX
            val y = packet.y - mc.thePlayer.posY
            val z = packet.z - mc.thePlayer.posZ
            val diff = sqrt(x * x + y * y + z * z)
            if (diff < 12) {
                event.cancelEvent()
                PacketUtils.sendPacketNoEvent(
                    C06PacketPlayerPosLook(
                        packet.x,
                        packet.y,
                        packet.z,
                        packet.getYaw(),
                        packet.getPitch(),
                        !mc.theWorld.isAirBlock(BlockPos(packet.x, packet.y - 0.1, packet.z))
                    )
                )
            }
        }
    }
}
